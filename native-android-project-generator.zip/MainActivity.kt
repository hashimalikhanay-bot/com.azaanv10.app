
package com.example.nativeapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * Native Android Activity written in Kotlin.
 * Minimum SDK 22 (Android 5.1.1) compatible.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // Inflates the layout defined in activity_main.xml
        setContentView(R.layout.activity_main)
    }
}
