rootProject.name = "NativeAndroidApp"
include(":app")