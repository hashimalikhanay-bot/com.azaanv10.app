
package com.example.nativeapp

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

/**
 * MainActivity: The primary entry point for this native Android application.
 * This class inherits from AppCompatActivity to provide compatibility for 
 * older Android versions while utilizing modern platform features.
 */
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // setContentView associates the Kotlin logic with the XML layout
        // defined in res/layout/activity_main.xml
        setContentView(R.layout.activity_main)
    }
}
