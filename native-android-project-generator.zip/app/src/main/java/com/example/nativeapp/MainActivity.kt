package com.azzan.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var imamSection: View
    private val PREFS_NAME = "ImamPrefs"
    private val PIN_KEY = "imam_pin"

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted: Boolean ->
        if (!isGranted) {
            Toast.makeText(this, "Notifications are required for Azaan alerts", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        imamSection = findViewById(R.id.imamSection)
        
        checkPermissions()
        checkBatteryOptimizations()
        setupUI()
    }

    private fun checkPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
                PackageManager.PERMISSION_GRANTED) {
                requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        }
    }

    private fun checkBatteryOptimizations() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val pm = getSystemService(POWER_SERVICE) as PowerManager
            if (!pm.isIgnoringBatteryOptimizations(packageName)) {
                MaterialAlertDialogBuilder(this)
                    .setTitle("Battery Optimization")
                    .setMessage("To ensure you never miss an Azaan call, please disable battery optimization.")
                    .setPositiveButton("Settings") { _, _ ->
                        val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS).apply {
                            data = Uri.parse("package:$packageName")
                        }
                        startActivity(intent)
                    }
                    .setNegativeButton("Ignore", null)
                    .show()
            }
        }
    }

    private fun setupUI() {
        val tvTitle = findViewById<TextView>(R.id.tvMasjidName)
        tvTitle.setOnLongClickListener {
            showPinDialog()
            true
        }

        findViewById<Button>(R.id.btnTestAzaan).setOnClickListener {
            Toast.makeText(this, "Starting stream...", Toast.LENGTH_SHORT).show()
            startAzaanService()
        }

        findViewById<Button>(R.id.btnStop).setOnClickListener {
            stopAzaanService()
        }

        findViewById<Button>(R.id.btnBroadcast).setOnClickListener {
            performBroadcast()
        }
    }

    private fun performBroadcast() {
        lifecycleScope.launch {
            Toast.makeText(this@MainActivity, "Broadcasting to all followers...", Toast.LENGTH_SHORT).show()
            val success = AzaanBroadcaster.sendAzaanBroadcast()
            if (success) {
                Toast.makeText(this@MainActivity, "BROADCAST SENT", Toast.LENGTH_LONG).show()
                startAzaanService() // Play for the broadcaster too
            } else {
                Toast.makeText(this@MainActivity, "Broadcast Failed", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showPinDialog() {
        val prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val storedPin = prefs.getString(PIN_KEY, null)

        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            hint = "4-digit PIN"
            textAlignment = View.TEXT_ALIGNMENT_CENTER
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(if (storedPin == null) "Set Imam PIN" else "Enter Imam PIN")
            .setView(input)
            .setPositiveButton("Confirm") { _, _ ->
                val pinInput = input.text.toString()
                if (storedPin == null) {
                    if (pinInput.length == 4) {
                        prefs.edit().putString(PIN_KEY, pinInput).apply()
                        activateImamMode()
                    }
                } else if (pinInput == storedPin) {
                    activateImamMode()
                } else {
                    Toast.makeText(this, "Incorrect PIN", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun activateImamMode() {
        imamSection.visibility = View.VISIBLE
        Toast.makeText(this, "Imam Mode Active", Toast.LENGTH_SHORT).show()
    }

    private fun startAzaanService() {
        val intent = Intent(this, PrayerAudioService::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(intent)
        } else {
            startService(intent)
        }
    }

    private fun stopAzaanService() {
        val intent = Intent(this, PrayerAudioService::class.java).apply {
            action = "STOP_AZAAN"
        }
        startService(intent)
        Toast.makeText(this, "Stream Stopped", Toast.LENGTH_SHORT).show()
    }
}