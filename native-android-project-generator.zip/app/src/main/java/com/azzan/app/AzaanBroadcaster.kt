package com.azzan.app

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

object AzaanBroadcaster {
    private val client = OkHttpClient()
    suspend fun sendAzaanBroadcast(): Boolean = withContext(Dispatchers.IO) {
        try {
            val body = JSONObject().apply {
                put("to", "/topics/azaan")
                put("notification", JSONObject().apply { put("title", "Azaan"); put("body", "Starting...") })
            }.toString().toRequestBody("application/json".toMediaType())
            
            val req = Request.Builder().url("https://fcm.googleapis.com/fcm/send")
                .addHeader("Authorization", "key=YOUR_KEY").post(body).build()
            client.newCall(req).execute().isSuccessful
        } catch (e: Exception) { false }
    }
}