package com.azzan.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat

class PrayerAudioService : Service() {
    private var mediaPlayer: MediaPlayer? = null
    private val URL = "https://www.dropbox.com/scl/fi/j6dew0rs076nzcsw1829e/azaan?rlkey=lpwe42p61du8two48v51k9mdz&st=17gxld95&dl=1"

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP_AZAAN") {
            stopSelf()
            return START_NOT_STICKY
        }
        
        startForeground(2, createNotification())
        mediaPlayer?.release()
        mediaPlayer = MediaPlayer().apply {
            setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).build())
            setDataSource(URL)
            setOnPreparedListener { it.start() }
            prepareAsync()
        }
        return START_NOT_STICKY
    }

    private fun createNotification() = NotificationCompat.Builder(this, "audio_ch")
        .setContentTitle("Azaan Streaming")
        .setSmallIcon(android.R.drawable.ic_media_play)
        .build().also {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val ch = NotificationChannel("audio_ch", "Audio", NotificationManager.IMPORTANCE_LOW)
                (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
            }
        }

    override fun onDestroy() {
        mediaPlayer?.release()
        super.onDestroy()
    }
}